# Creative File Studio

ローカル環境で動く、創作支援向けのファイル管理アプリです。作品、キャラ設定、取り込み画像、世界観資料、生成プロンプト、音声、動画をまとめて扱えます。
動画生成は公式Seedance APIまたはOpenRouterの動画モデル、音声生成はOpenRouter TTS、ElevenLabs、ローカル Irodori-TTS を切り替えて使えます。

## 起動

```bash
npm start
```

ブラウザで `http://localhost:4173` を開きます。

### Windowsで起動

`start-windows.bat` をダブルクリックします。

終了するときは、開いた黒い画面を閉じるか `Ctrl + C` を押します。

### Macで起動

初回だけターミナルで実行権限を付けます。

```bash
chmod +x start-mac.command
```

その後は `start-mac.command` をダブルクリックします。

終了するときは、開いたターミナルを閉じるか `Ctrl + C` を押します。

すでに `http://localhost:4173` でサーバーが起動している場合、`start-mac.command` は新しく起動せずブラウザだけ開きます。エラーが起きた場合もターミナルを閉じず、原因を表示します。

4173番ポートが別アプリで使用中の場合は、4174以降の空きポートを自動で探して起動します。その場合はターミナルに表示されたURLを使ってください。

起動に失敗した場合は、同じフォルダに `creative-file-studio-start.log` が作成されます。そこに表示されたエラー内容を確認してください。

## ユーザーデータを保持したまま更新

GitHub Releasesの最新版ZIP、手元の更新用ZIP、または展開済みの最新版フォルダを使って、`data/` を残したままアプリ本体だけ更新できます。

最新版ZIPのRelease添付URL:

```text
https://github.com/Guarhiro/creative-file-studio/releases/latest/download/creative-file-studio-upload.zip
```

保持されるもの:

- `data/db.json`
- `data/uploads/`
- `.env`
- `node_modules/`
- `creative-file-studio-start.log`

### Windowsで更新

`update-windows.bat` をダブルクリックします。

- Enterだけ押す: GitHub Releasesから最新版を自動取得して更新
- パスを入力する: 手元の更新ZIPまたは展開済み最新版フォルダから更新

### Macで更新

初回だけ実行権限を付けます。

```bash
chmod +x update-mac.command
```

その後は `update-mac.command` をダブルクリックします。

- Enterだけ押す: GitHub Releasesから最新版を自動取得して更新
- ZIP/フォルダをドラッグしてEnter: 手元の更新ZIPまたは展開済み最新版フォルダから更新

更新後、起動中のサーバーがある場合は `Ctrl + C` で停止してから再起動してください。

## Release ZIPの作成

GitHub Releasesには、最新版の公開構成を `creative-file-studio-upload.zip` という名前で添付します。

ZIPに含めるもの:

- `.gitignore`
- `.env.example`
- `README.md`
- `package.json`
- `server.js`
- `Seedance2.0_Prompt_Guide_v2.md`
- `start-mac.command`
- `start-windows.bat`
- `update-mac.command`
- `update-windows.bat`
- `scripts/setup-irodori.sh`
- `public/`
- `data/.gitkeep`

ZIPに含めないもの:

- `data/db.json`
- `data/uploads/`
- `data/audios/`
- `data/videos/`
- `vendor/`
- `.env`
- `node_modules/`
- `.DS_Store`
- `creative-file-studio-start.log`

## 主な機能

### 作品とキャラ管理

- 作品単位でキャラ、世界観設定、その他情報を管理
- キャラ名、メモ、基本立ち絵、ベースプロンプト、ネガティブプロンプトを保存
- キャラごとにプロンプト形式を自然言語/タグから選択
- 基本立ち絵からOpenRouter経由で生成プロンプトを抽出
- 作品タイトルの並び順を画面上で変更して保存

### 世界観設定と作品資料

- 作品情報欄で世界観設定を閲覧、編集
- 画像シート最大5枚、Markdown/Textファイル、直接入力テキストを資料として取り込み
- OpenRouterで設定資料を読み取り、世界観、キャラ、衣装、道具、建築、配色、保持すべき要素を構造化
- その他情報として背景、場所、小物、設定画像などを作品に紐づけて管理

### 画像取込、画像一覧、画像整理

- 複数画像をまとめて取り込み
- 取り込み時に作品、キャラ、保存先を手動指定
- 作品内キャラだけを候補にしたAI判別
- 画像の縦横サイズ、アスペクト比、判別状態を保存
- 画像一覧で作品別、キャラ別に閲覧
- 画像整理で未設定、判別失敗、判別済みを絞り込み
- 大量画像でも扱いやすいページ表示、表示件数切り替え、遅延読み込み
- Finderで保存場所を表示
- 取り込み履歴だけの削除、または画像ファイル本体を含む完全削除

### Prompt Lab

- 表情差分、衣装差分、イベントシーンなどの生成プロンプトをまとめて作成
- 作品情報、世界観設定、キャラメモを反映したプロンプト生成
- キャラ設定に合わせて自然言語またはタグ形式で出力
- キャラメモを加味するかどうかを切り替え

### 動画生成

- 作品情報、世界観、キャラ情報、参照素材を読んだ動画生成エージェント
- 公式Seedance APIまたはOpenRouter動画モデルを選択
- OpenRouterではSeedance、Kling、Veo、Soraなどの動画モデルをプルダウンで選択
- モデルごとの対応秒数、アスペクト比、解像度、開始/終了フレーム設定を画面に反映
- 秒数、アスペクト比、解像度、音声生成、カメラ固定、透かし、Seedを指定
- 参照素材として取り込み画像、キャラ立ち絵、その他情報の参考画像、動画、音声を選択
- 作品、キャラ、素材種別で参照素材を絞り込み
- 選択中の参照素材を一覧の先頭に表示し、解除すると元の並びに戻す
- 生成待ちジョブの状態確認、完成動画の自動保存
- 生成履歴から動画、プロンプト、保存先を確認
- 今月の動画生成コスト、日本円換算、現在モデルの1秒料金を表示
- OpenRouter動画モデルの現在料金とUSD/JPYレートをボタンで取得

### 音声生成

- 作品情報、世界観、キャラ情報を読んだ音声生成エージェント
- OpenRouter TTS、ElevenLabs、ローカル Irodori-TTS を切り替え
- OpenRouterでは `google/gemini-3.1-flash-tts-preview` によるTTS生成
- ElevenLabsではVoice ID、モデル、出力形式、Stability、Similarity、Style、Speed、Speaker Boost、言語コード、Seedを指定
- Irodori-TTSではVoiceDesign/Reference、Steps、候補数、Seed、CFG、デバイス、精度、参照音声を指定
- 生成音声をキャラ情報に紐づけ、作品ページのキャラカードから確認
- キャラに紐づいた生成音声を、動画生成の参照素材「音声」として選択

### 設定とモデル管理

- OpenRouter APIキー、ElevenLabs APIキー、Seedance APIキーをブラウザのlocalStorageに保存
- 画像判別、テキスト生成、世界観読み込み、動画エージェント、音声エージェントのモデルを個別に設定
- OpenRouterのモデル一覧と動画モデル対応設定を再取得
- Seedance API Base URLを公式 / OpenRouterから選択
- Irodori-TTSの既存フォルダ指定、または `scripts/setup-irodori.sh` による取得

## 保存場所

- 作品、キャラ、画像メタデータ: `data/db.json`
- 取り込み画像、立ち絵: `data/uploads/作品名/キャラ名/`
- 生成完了後に保存された音声: `data/audios/`
- 動画生成用に追加した素材: `data/uploads/作品名/_動画生成_画像/`、`_動画生成_動画/`、`_動画生成_音声/`
- 生成完了後に保存された動画: `data/videos/`
- OpenRouter API キー: ブラウザの localStorage
- ElevenLabs API キー: ブラウザの localStorage
- Seedance API キー: ブラウザの localStorage

既存の `data/uploads/` 直下にある画像は、アプリ読み込み時に現在の作品・キャラ割当に合わせて自動で移動されます。未割当画像は `作品名/_未割当/` に入ります。

画像整理の「履歴削除」は `data/db.json` から取り込み記録だけを削除します。画像ファイル本体とキャラ設定の立ち絵は削除しません。

画像一覧の「完全削除」は取り込み記録と画像ファイル本体を削除します。ただし同じ画像ファイルが別の履歴やキャラ立ち絵で使われている場合、ファイル本体は残して登録だけ削除します。

## GitHub 公開時の注意

`.gitignore` で以下を公開対象から外しています。

- `data/*`
- `node_modules/`
- `vendor/`
- `.env`
- `.DS_Store`

`data/.gitkeep` だけを含めることで、空の `data/` フォルダはリポジトリに残ります。作品データ、キャラ設定、プロンプト、取り込み画像は公開されません。

## OpenRouter

設定画面で API キーとモデルIDを保存してください。

- 画像判別モデル: 取り込み画像のキャラ判定に使います。vision 対応モデルを指定します。
- テキスト生成モデル: 通常のテキスト生成に使います。
- 世界観読み込みモデル: 設定シート画像、Markdown/Textファイル、直接入力テキストの読解に使います。vision と長文JSONに強いモデルが向いています。
- 動画エージェントモデル: 動画生成画面のチャットエージェントに使います。参照画像を読むため、vision 対応モデルが向いています。
- 音声エージェントモデル: 音声生成画面のチャットエージェントに使います。実際の音声生成は、音声生成画面で選んだ OpenRouter TTS、ElevenLabs、または Irodori-TTS で行います。

モデル一覧は設定画面の「モデル一覧を再取得」で OpenRouter から読み込みます。

## 音声生成

音声生成画面では、作品、キャラ、生成方式、読み上げテキストを指定して音声を作成できます。キャラ指定は任意です。

生成方式は以下から選択できます。

- OpenRouter / Gemini TTS: `google/gemini-3.1-flash-tts-preview` を使います。
- ElevenLabs: 指定した Voice ID とモデルでElevenLabs APIを呼び出し、音声ファイルを保存します。
- Irodori-TTS: この端末上の Irodori-TTS を `uv run python infer.py` で実行し、WAVを保存します。

OpenRouter選択時:

- 生成モデル: `google/gemini-3.1-flash-tts-preview`
- 出力形式: OpenRouterからPCMで受け取り、アプリ内ではWAVとして保存します。
- APIキー: 設定画面のOpenRouter APIキーを使います。
- 演技指示: 声質、感情、速度、間、距離感、アクセント、インライン音声タグを指定できます。
- エージェント: 作品情報、世界観、キャラメモを参照して、読み上げ本文と演技指示を分けて作ります。生成時は両方をGemini TTS向けのプロンプトに合成します。

ElevenLabs選択時:

- APIキー: 設定画面のElevenLabs APIキーを使います。
- Voice ID: 既定値を設定画面で保存でき、音声生成画面でもプルダウンから生成ごとに変更できます。
- 音声一覧: 設定画面または音声生成画面の「音声一覧取得」で利用可能なVoice IDを読み込み、声の名前付きプルダウンから選べます。
- モデル: `eleven_multilingual_v2`、`eleven_turbo_v2_5`、`eleven_flash_v2_5`、`eleven_v3` などをプルダウンから選べます。「モデル一覧取得」でElevenLabs APIのTTS対応モデルも読み込めます。
- 出力形式: MP3、WAV、PCMを選べます。PCMはアプリ内で再生しやすいようWAVに変換して保存します。
- 演技指示: 音声生成画面で声質、感情、速度、間、距離感をメモとして指定でき、生成履歴にも保存されます。
- Voice settings: Stability、Similarity、Style、Speed、Speaker Boost、言語コード、Seedを指定できます。

Irodori-TTS選択時:

- 出力形式: WAV
- VoiceDesign / Reference を選択できます。
- Steps、候補数、Seed、Text CFG、Caption CFG、Speaker CFG、モデル/Codecのデバイスと精度、カスタムチェックポイントを指定できます。
- Reference用の参照音声をアップロードできます。
- 設定画面の「Irodori-TTS連携」で既存のIrodori-TTSフォルダを指定できます。
- 未導入環境では「Irodori-TTSを取得」を押すと `scripts/setup-irodori.sh` が `vendor/Irodori-TTS` にGitHubから取得し、`uv sync` を実行します。`uv` がない場合はインストール案内が表示されます。

キャラを指定して生成した音声は、そのキャラに紐づいて保存されます。作品ページのキャラカードから最新音声を再生でき、「音声一覧」で過去の音声も確認できます。

動画生成画面で参照素材の種類を「音声」にすると、アップロード済み音声に加えて、キャラに紐づいた生成音声も表示されます。キャラで絞り込むと、そのキャラの音声だけを参照素材として選べます。

## 動画生成

設定画面の Seedance セクションで以下を設定します。

- API キー: 公式APIを使う場合は公式側のキー、OpenRouterを使う場合はOpenRouterキーを使います。OpenRouterを選んだ場合は、上のOpenRouter APIキー欄のキーを優先して使います。
- API Base URL: `公式 BytePlus / Volcengine` または `OpenRouter` をプルダウンで選択します。
- 動画モデル: 公式APIでは `dreamina-seedance-2-0-260128`、OpenRouterでは動画モデル一覧から選択します。
- 既定解像度: 動画生成画面の初期値として使います。

OpenRouter選択時は、動画モデル専用APIから対応設定を取得します。取得できない場合も、以下のモデルはフォールバック設定で選択できます。

- `bytedance/seedance-2.0`
- `bytedance/seedance-2.0-fast`
- `kwaivgi/kling-v3.0-std`
- `kwaivgi/kling-v3.0-pro`
- `google/veo-3.1-fast`
- `google/veo-3.1-lite`
- `google/veo-3.1`
- `openai/sora-2-pro`

動画生成画面では、作品、キャラ、秒数、アスペクト比、解像度、音声生成、カメラ固定、透かし、Seedを指定できます。

画面上部には、今月作成した動画ジョブ全体のコスト目安を表示します。

- `現在料金を取得`: OpenRouterの動画モデル料金とUSD/JPYレートを取得して保存します。
- 日本円概算: 生成履歴の実コストが取得できる場合は実コストを優先し、未取得のジョブはモデル、秒数、解像度、アスペクト比から概算します。
- 現在モデルの1秒料金: 選択中の動画モデル、解像度、アスペクト比に応じた秒単価を表示します。

料金取得にはOpenRouter APIキーが必要です。取得できない場合も、保存済み料金またはフォールバック料金で概算表示します。

参照素材には以下を使えます。

- 取り込み済み画像
- キャラの基本立ち絵
- その他情報の参考画像
- 動画生成画面から追加した画像、動画、音声
- 音声生成画面で作成し、キャラに紐づいた音声

参照素材は作品、キャラ、素材種別で絞り込めます。チェックした素材はすぐ解除できるよう一覧の先頭に移動し、チェックを外すと元の並びに戻ります。

生成が完了すると、動画は自動で `data/videos/` に保存されます。保存済み動画は動画生成画面のジョブ一覧から確認できます。

## トラブルシュート

更新後に新しい機能が動かない、または `Not found` が出る場合は、起動中のサーバーが古いままの可能性があります。ターミナルで `Ctrl + C` を押して停止し、もう一度起動してください。ブラウザもリロードしてください。

Seedance/OpenRouterの動画生成で `401` が出る場合は、設定画面のOpenRouter APIキーとSeedance APIキーを確認してください。OpenRouter経由の完成動画は、保存時にも認証が必要になることがあります。このアプリはOpenRouter選択時に認証付きダウンロードを試します。

生成ジョブの「更新」を押しても古いエラーが残る場合は、アプリを完全に再起動してから再度「更新」を押してください。
